import { useState, useEffect } from 'react'
import axios from 'axios'
import Navigation from './Navigation'

const API_URL = 'http://localhost:3001/api';

function Collaborations({ setPage }) {
  const [collaborations, setCollaborations] = useState([]);
  const [players, setPlayers] = useState([]);
  const [developers, setDevelopers] = useState([]);
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [formError, setFormError] = useState(null);
  const [filterStatus, setFilterStatus] = useState('');

  // New request form fields
  const [showRequestForm, setShowRequestForm] = useState(false);
  const [reqPlayerId, setReqPlayerId] = useState('');
  const [reqGameId, setReqGameId] = useState('');
  const [reqDescription, setReqDescription] = useState('');
  const [reqHours, setReqHours] = useState('');
  const [reqMilestones, setReqMilestones] = useState('');

  // Accept form fields
  const [acceptingId, setAcceptingId] = useState(null);
  const [accDeveloperId, setAccDeveloperId] = useState('');
  const [accStartDate, setAccStartDate] = useState('');
  const [accEndDate, setAccEndDate] = useState('');

  // Status update fields
  const [updatingStatusId, setUpdatingStatusId] = useState(null);
  const [newStatus, setNewStatus] = useState('');

  // Load players, developers and games once when the page opens
  useEffect(function() {
    axios.get(`${API_URL}/players`)
      .then(function(res) { setPlayers(res.data); })
      .catch(function(err) { console.log('Error loading players: ' + err.message); });

    axios.get(`${API_URL}/developers`)
      .then(function(res) { setDevelopers(res.data); })
      .catch(function(err) { console.log('Error loading developers: ' + err.message); });

    axios.get(`${API_URL}/games`)
      .then(function(res) { setGames(res.data); })
      .catch(function(err) { console.log('Error loading games: ' + err.message); });
  }, []);

  // Load collaborations whenever filterStatus changes
  const fetchCollaborations = () => {
    setLoading(true);
    let url = `${API_URL}/collaborations`;
    if (filterStatus) {
      url = url + '?status=' + filterStatus;
    }
    axios.get(url)
      .then(function(res) {
        setCollaborations(res.data);
        setLoading(false);
      })
      .catch(function(err) {
        setError('Error loading collaborations: ' + err.message);
        setLoading(false);
      });
  };

  useEffect(function() {
    fetchCollaborations();
  }, [filterStatus]);

  // Submit a new collaboration request
  const handleRequestSubmit = async (e) => {
    e.preventDefault();
    setFormError(null);

    // Build milestones array from the textarea (one per line)
    const milestoneList = [];
    if (reqMilestones !== '') {
      const lines = reqMilestones.split('\n');
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line !== '') {
          milestoneList.push({ description: line });
        }
      }
    }

    try {
      await axios.post(`${API_URL}/collaborations`, {
        playerId: reqPlayerId,
        gameId: reqGameId,
        requestDescription: reqDescription,
        estimatedHours: Number(reqHours),
        milestones: milestoneList
      });
      setShowRequestForm(false);
      setReqPlayerId('');
      setReqGameId('');
      setReqDescription('');
      setReqHours('');
      setReqMilestones('');
      fetchCollaborations();
    } catch (err) {
      setFormError(err.response?.data?.error || err.message);
    }
  };

  // Accept a collaboration and assign a developer
  const handleAccept = async (e) => {
    e.preventDefault();
    setFormError(null);
    try {
      await axios.post(`${API_URL}/collaborations/${acceptingId}/accept`, {
        developerId: accDeveloperId,
        startDate: accStartDate || undefined,
        endDate: accEndDate || undefined
      });
      setAcceptingId(null);
      setAccDeveloperId('');
      setAccStartDate('');
      setAccEndDate('');
      fetchCollaborations();
    } catch (err) {
      setFormError(err.response?.data?.error || err.message);
    }
  };

  // Reject a collaboration request
  const handleReject = async (id) => {
    if (!window.confirm('Reject this collaboration request?')) return;
    try {
      await axios.post(`${API_URL}/collaborations/${id}/reject`);
      fetchCollaborations();
    } catch (err) {
      setError('Reject failed: ' + err.message);
    }
  };

  // Update the status of a collaboration
  const handleStatusUpdate = async (e) => {
    e.preventDefault();
    try {
      await axios.patch(`${API_URL}/collaborations/${updatingStatusId}/status`, { status: newStatus });
      setUpdatingStatusId(null);
      fetchCollaborations();
    } catch (err) {
      setError('Status update failed: ' + err.message);
    }
  };

  // Delete a collaboration
  const handleDelete = async (id) => {
    if (!window.confirm('Delete this collaboration request?')) return;
    try {
      await axios.delete(`${API_URL}/collaborations/${id}`);
      fetchCollaborations();
    } catch (err) {
      setError('Delete failed: ' + err.message);
    }
  };

  const openAcceptForm = (collabId, currentStatus) => {
    setAcceptingId(collabId);
    setAccDeveloperId('');
    setAccStartDate('');
    setAccEndDate('');
    setFormError(null);
  };

  if (loading) return <div className="container"><div className="loading">Loading collaborations...</div></div>;
  if (error) return <div className="container"><div className="error">{error}</div></div>;

  // Only players with premium or elite membership can submit requests
  const eligiblePlayers = [];
  for (let i = 0; i < players.length; i++) {
    if (players[i].membershipLevel === 'premium' || players[i].membershipLevel === 'elite') {
      eligiblePlayers.push(players[i]);
    }
  }

  // Only developers who are currently available
  const availableDevelopers = [];
  for (let i = 0; i < developers.length; i++) {
    if (developers[i].available === true) {
      availableDevelopers.push(developers[i]);
    }
  }

  return (
    <div className="container">
      <Navigation setPage={setPage} />
      <h1>🤝 Collaborations</h1>

      <div className="filter-bar">
        <label>Status:
          <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
            <option value="">All</option>
            <option value="pending">pending</option>
            <option value="accepted">accepted</option>
            <option value="in-progress">in-progress</option>
            <option value="completed">completed</option>
            <option value="cancelled">cancelled</option>
            <option value="rejected">rejected</option>
          </select>
        </label>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <p>Total Requests: {collaborations.length}</p>
        <button className="btn-primary" onClick={() => { setShowRequestForm(true); setFormError(null); }}>
          + Submit Request
        </button>
      </div>

      {/* New Collaboration Request Form */}
      {showRequestForm && (
        <div className="modal-overlay">
          <div className="modal">
            <h2>Submit Customization Request</h2>
            <p style={{ color: '#666', fontSize: '13px', marginBottom: '10px' }}>
              Only premium or elite members can submit requests.
            </p>
            {formError && <div className="error">{formError}</div>}
            <form onSubmit={handleRequestSubmit} className="crud-form">
              <label>Player * (premium/elite only)
                <select value={reqPlayerId} onChange={e => setReqPlayerId(e.target.value)} required>
                  <option value="">Select a player</option>
                  {eligiblePlayers.map(p => (
                    <option key={p._id} value={p._id}>{p.name} ({p.membershipLevel})</option>
                  ))}
                </select>
              </label>
              <label>Game *
                <select value={reqGameId} onChange={e => setReqGameId(e.target.value)} required>
                  <option value="">Select a game</option>
                  {games.map(g => (
                    <option key={g._id} value={g._id}>{g.title} ({g.genre})</option>
                  ))}
                </select>
              </label>
              <label>Request Description *
                <textarea value={reqDescription} onChange={e => setReqDescription(e.target.value)} rows="3" required />
              </label>
              <label>Estimated Hours *
                <input type="number" min="1" value={reqHours} onChange={e => setReqHours(e.target.value)} required />
              </label>
              <label>Milestones (one per line, optional)
                <textarea value={reqMilestones} onChange={e => setReqMilestones(e.target.value)} rows="3" placeholder="Design phase&#10;Development phase&#10;Testing phase" />
              </label>
              <div className="form-actions">
                <button type="submit" className="btn-primary">Submit Request</button>
                <button type="button" className="btn-secondary" onClick={() => setShowRequestForm(false)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Accept Form */}
      {acceptingId && (
        <div className="modal-overlay">
          <div className="modal">
            <h2>Accept Collaboration Request</h2>
            {formError && <div className="error">{formError}</div>}
            <form onSubmit={handleAccept} className="crud-form">
              <label>Developer * (available only)
                <select value={acceptForm.developerId} onChange={e => setAcceptForm(p => ({ ...p, developerId: e.target.value }))} required>
                  <option value="">Select a developer</option>
                  {availableDevelopers.map(d => (
                    <option key={d._id} value={d._id}>{d.name} (${d.hourlyRate}/hr)</option>
                  ))}
                </select>
              </label>
              <label>Start Date
                <input type="date" value={acceptForm.startDate} onChange={e => setAcceptForm(p => ({ ...p, startDate: e.target.value }))} />
              </label>
              <label>End Date
                <input type="date" value={acceptForm.endDate} onChange={e => setAcceptForm(p => ({ ...p, endDate: e.target.value }))} />
              </label>
              <div className="form-actions">
                <button type="submit" className="btn-primary">Accept & Assign Developer</button>
                <button type="button" className="btn-secondary" onClick={() => { setAcceptingId(null); setFormError(null); }}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Status Update Form */}
      {updatingStatusId && (
        <div className="modal-overlay">
          <div className="modal">
            <h2>Update Status</h2>
            <form onSubmit={handleStatusUpdate} className="crud-form">
              <label>New Status *
                <select value={newStatus} onChange={e => setNewStatus(e.target.value)} required>
                  <option value="">Select status</option>
                  <option value="pending">pending</option>
                  <option value="accepted">accepted</option>
                  <option value="in-progress">in-progress</option>
                  <option value="completed">completed</option>
                  <option value="cancelled">cancelled</option>
                  <option value="rejected">rejected</option>
                </select>
              </label>
              <div className="form-actions">
                <button type="submit" className="btn-primary">Update Status</button>
                <button type="button" className="btn-secondary" onClick={() => setUpdatingStatusId(null)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="items-list">
        {collaborations.map(collab => (
          <div key={collab._id} className="item-card">
            <h3>Request #{collab._id.slice(-6)}</h3>
            <p><strong>Player:</strong> {collab.playerId ? collab.playerId.name : 'N/A'} ({collab.playerId ? collab.playerId.membershipLevel : 'N/A'})</p>
            <p><strong>Game:</strong> {collab.gameId ? collab.gameId.title : 'N/A'}</p>
            <p><strong>Developer:</strong> {collab.developerId ? collab.developerId.name : 'Not assigned'}</p>
            <p><strong>Description:</strong> {collab.requestDescription}</p>
            <p><strong>Estimated Hours:</strong> {collab.estimatedHours}</p>
            <p><strong>Total Cost:</strong> ${collab.totalCost || 0}</p>
            <p><strong>Status:</strong> <span className={'status-badge status-' + collab.status}>{collab.status}</span></p>
            {collab.timeline && collab.timeline.startDate && (
              <p><strong>Timeline:</strong> {new Date(collab.timeline.startDate).toLocaleDateString()}
              {collab.timeline.endDate && ' — ' + new Date(collab.timeline.endDate).toLocaleDateString()}</p>
            )}
            {collab.milestones && collab.milestones.length > 0 && (
              <div>
                <strong>Milestones:</strong>
                <ul style={{ marginLeft: '16px', marginTop: '4px' }}>
                  {collab.milestones.map((m, i) => (
                    <li key={i} style={{ color: m.completed ? '#28a745' : '#666' }}>
                      {m.completed ? '✅' : '⬜'} {m.description}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <div className="card-actions">
              {collab.status === 'pending' && (
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button className="btn-primary" onClick={() => openAcceptForm(collab._id)}>Accept</button>
                  <button className="btn-delete" onClick={() => handleReject(collab._id)}>Reject</button>
                </div>
              )}
              <button className="btn-edit" onClick={() => { setUpdatingStatusId(collab._id); setNewStatus(collab.status); }}>Update Status</button>
              <button className="btn-delete" onClick={() => handleDelete(collab._id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Collaborations

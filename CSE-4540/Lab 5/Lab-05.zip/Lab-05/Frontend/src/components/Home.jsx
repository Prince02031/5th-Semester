function Home({ setPage }) {
  return (
    <div className="container">
      <h1>🎮 Game Management System</h1>
      <p style={{ textAlign: 'center', fontSize: '18px', color: '#666', marginBottom: '20px' }}>
        Welcome! Choose a section to manage:
      </p>
      <div className="button-grid">
        <button className="home-button" onClick={() => setPage('games')}>
          <div style={{ fontSize: '48px' }}>🎲</div>
          <div>Games</div>
        </button>
        <button className="home-button" onClick={() => setPage('players')}>
          <div style={{ fontSize: '48px' }}>👤</div>
          <div>Players</div>
        </button>
        <button className="home-button" onClick={() => setPage('developers')}>
          <div style={{ fontSize: '48px' }}>💻</div>
          <div>Developers</div>
        </button>
        <button className="home-button" onClick={() => setPage('collaborations')}>
          <div style={{ fontSize: '48px' }}>🤝</div>
          <div>Collaborations</div>
        </button>
      </div>
    </div>
  );
}

export default Home

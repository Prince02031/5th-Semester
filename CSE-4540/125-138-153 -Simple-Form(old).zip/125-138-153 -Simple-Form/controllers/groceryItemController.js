const GroceryItem = require('../models/groceryItemModel');

// Get all grocery items
const getAllGroceryItems = async (req, res) => {
  const groceryItems = await GroceryItem.find().sort({createdAt: -1});
  res.status(200).json(groceryItems);
};

// Get a single grocery item
const getGroceryItemById = async (req, res) => {
  const { id } = req.params;
  const groceryItem = await GroceryItem.findById(id);

  if (!groceryItem) {
    return res.status(404).json({error: 'No such grocery item'});
  }

  res.status(200).json(groceryItem);
};

// Create a new grocery item
const createGroceryItem = async (req, res) => {
  try {
    const groceryItem = await GroceryItem.create(req.body);
    res.status(200).json(groceryItem);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Delete a grocery item
const deleteGroceryItem = async (req, res) => {
  const { id } = req.params;
  const groceryItem = await GroceryItem.findOneAndDelete({_id: id});

  if(!groceryItem) {
    return res.status(400).json({error: 'No such grocery item'});
  }

  res.status(200).json(groceryItem);
};

// Update a grocery item
const updateGroceryItem = async (req, res) => {
  const { id } = req.params;
  const groceryItem = await GroceryItem.findOneAndUpdate({_id: id}, {
    ...req.body
  }, {new: true});

  if (!groceryItem) {
    return res.status(400).json({error: 'No such grocery item'});
  }

  res.status(200).json(groceryItem);
};

// Get expiring items (items expiring within next 7 days)
const getExpiringItems = async (req, res) => {
  try {
    const sevenDaysFromNow = new Date();
    sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);
    
    const expiringItems = await GroceryItem.find({
      expiryDate: { $lte: sevenDaysFromNow, $gte: new Date() },
      status: { $in: ['Available', 'Partially Used'] }
    });
    
    res.status(200).json(expiringItems);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

module.exports = {
  getAllGroceryItems,
  getGroceryItemById,
  createGroceryItem,
  deleteGroceryItem,
  updateGroceryItem,
  getExpiringItems
};

const User = require('../models/userModel');

// Get all users
const getAllUsers = async (req, res) => {
  const users = await User.find().sort({createdAt: -1});
  res.status(200).json(users);
};

// Get a single user
const getUserById = async (req, res) => {
  const { id } = req.params;
  const user = await User.findById(id);

  if (!user) {
    return res.status(404).json({error: 'No such user'});
  }

  res.status(200).json(user);
};

// Create a new user
const createUser = async (req, res) => {
  try {
    const user = await User.create(req.body);
    res.status(200).json(user);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Delete a user
const deleteUser = async (req, res) => {
  const { id } = req.params;
  const user = await User.findOneAndDelete({_id: id});

  if(!user) {
    return res.status(400).json({error: 'No such user'});
  }

  res.status(200).json(user);
};

// Update a user
const updateUser = async (req, res) => {
  const { id } = req.params;
  const user = await User.findOneAndUpdate({_id: id}, {
    ...req.body
  }, {new: true});

  if (!user) {
    return res.status(400).json({error: 'No such user'});
  }

  res.status(200).json(user);
};

module.exports = {
  getAllUsers,
  getUserById,
  createUser,
  deleteUser,
  updateUser
};

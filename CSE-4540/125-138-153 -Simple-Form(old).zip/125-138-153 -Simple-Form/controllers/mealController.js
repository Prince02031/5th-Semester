const Meal = require('../models/mealModel');
const GroceryItem = require('../models/groceryItemModel');

// Get all meals
const getAllMeals = async (req, res) => {
  const meals = await Meal.find().populate('ingredients').sort({createdAt: -1});
  res.status(200).json(meals);
};

// Get a single meal
const getMealById = async (req, res) => {
  const { id } = req.params;
  const meal = await Meal.findById(id).populate('ingredients');

  if (!meal) {
    return res.status(404).json({error: 'No such meal'});
  }

  res.status(200).json(meal);
};

// Create a new meal
const createMeal = async (req, res) => {
  try {
    const meal = await Meal.create(req.body);
    res.status(200).json(meal);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Delete a meal
const deleteMeal = async (req, res) => {
  const { id } = req.params;
  const meal = await Meal.findOneAndDelete({_id: id});

  if(!meal) {
    return res.status(400).json({error: 'No such meal'});
  }

  res.status(200).json(meal);
};

// Update a meal
const updateMeal = async (req, res) => {
  const { id } = req.params;
  const meal = await Meal.findOneAndUpdate({_id: id}, {
    ...req.body
  }, {new: true}).populate('ingredients');

  if (!meal) {
    return res.status(400).json({error: 'No such meal'});
  }

  res.status(200).json(meal);
};

// Get meals by date range
const getMealsByDateRange = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    const meals = await Meal.find({
      plannedDate: {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      }
    }).populate('ingredients');
    
    res.status(200).json(meals);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

module.exports = {
  getAllMeals,
  getMealById,
  createMeal,
  deleteMeal,
  updateMeal,
  getMealsByDateRange
};

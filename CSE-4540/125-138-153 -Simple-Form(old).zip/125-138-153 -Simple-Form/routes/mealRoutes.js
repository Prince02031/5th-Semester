const express = require('express');
const router = express.Router();
const {
  getAllMeals,
  getMealById,
  createMeal,
  deleteMeal,
  updateMeal,
  getMealsByDateRange
} = require('../controllers/mealController');

// GET all meals
router.get('/', getAllMeals);

// GET meals by date range
router.get('/date-range', getMealsByDateRange);

// GET a single meal
router.get('/:id', getMealById);

// POST a new meal
router.post('/', createMeal);

// DELETE a meal
router.delete('/:id', deleteMeal);

// UPDATE a meal
router.patch('/:id', updateMeal);

module.exports = router;

const express = require('express');
const router = express.Router();
const {
  getAllGroceryItems,
  getGroceryItemById,
  createGroceryItem,
  deleteGroceryItem,
  updateGroceryItem,
  getExpiringItems
} = require('../controllers/groceryItemController');

// GET all grocery items
router.get('/', getAllGroceryItems);

// GET expiring items
router.get('/expiring', getExpiringItems);

// GET a single grocery item
router.get('/:id', getGroceryItemById);

// POST a new grocery item
router.post('/', createGroceryItem);

// DELETE a grocery item
router.delete('/:id', deleteGroceryItem);

// UPDATE a grocery item
router.patch('/:id', updateGroceryItem);

module.exports = router;

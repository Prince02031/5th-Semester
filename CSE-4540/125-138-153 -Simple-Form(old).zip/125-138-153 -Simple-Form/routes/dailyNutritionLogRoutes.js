const express = require('express');
const router = express.Router();
const {
  getAllDailyNutritionLogs,
  getDailyNutritionLogById,
  createDailyNutritionLog,
  deleteDailyNutritionLog,
  updateDailyNutritionLog,
  getDailyNutritionLogsByUser
} = require('../controllers/dailyNutritionLogController');

// GET all daily nutrition logs
router.get('/', getAllDailyNutritionLogs);

// GET daily nutrition logs by user
router.get('/user/:userId', getDailyNutritionLogsByUser);

// GET a single daily nutrition log
router.get('/:id', getDailyNutritionLogById);

// POST a new daily nutrition log
router.post('/', createDailyNutritionLog);

// DELETE a daily nutrition log
router.delete('/:id', deleteDailyNutritionLog);

// UPDATE a daily nutrition log
router.patch('/:id', updateDailyNutritionLog);

module.exports = router;

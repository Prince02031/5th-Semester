const express = require('express');
const router = express.Router();
const {
  getAllUsers,
  getUserById,
  createUser,
  deleteUser,
  updateUser
} = require('../controllers/userController');

// GET all users
router.get('/', getAllUsers);

// GET a single user
router.get('/:id', getUserById);

// POST a new user
router.post('/', createUser);

// DELETE a user
router.delete('/:id', deleteUser);

// UPDATE a user
router.patch('/:id', updateUser);

module.exports = router;

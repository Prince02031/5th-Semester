const express = require('express');
const router = express.Router();
const {
  getAllWasteLogs,
  getWasteLogById,
  createWasteLog,
  deleteWasteLog,
  updateWasteLog,
  getWasteAnalytics
} = require('../controllers/wasteLogController');

// GET all waste logs
router.get('/', getAllWasteLogs);

// GET waste analytics
router.get('/analytics', getWasteAnalytics);

// GET a single waste log
router.get('/:id', getWasteLogById);

// POST a new waste log
router.post('/', createWasteLog);

// DELETE a waste log
router.delete('/:id', deleteWasteLog);

// UPDATE a waste log
router.patch('/:id', updateWasteLog);

module.exports = router;

const express = require('express');
const router = express.Router();
const {
  getAllNutritionInfo,
  getNutritionInfoById,
  createNutritionInfo,
  deleteNutritionInfo,
  updateNutritionInfo
} = require('../controllers/nutritionInfoController');

// GET all nutrition info
router.get('/', getAllNutritionInfo);

// GET a single nutrition info
router.get('/:id', getNutritionInfoById);

// POST a new nutrition info
router.post('/', createNutritionInfo);

// DELETE a nutrition info
router.delete('/:id', deleteNutritionInfo);

// UPDATE a nutrition info
router.patch('/:id', updateNutritionInfo);

module.exports = router;

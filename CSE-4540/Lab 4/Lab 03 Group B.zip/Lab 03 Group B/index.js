const express = require('express');
const app = express();

require('dotenv').config();
const PORT = process.env.PORT || 3000;


//middleware
app.use(express.json()); 


//routes
const router = require('./routes/gameRoutes');
app.use('/api/games',router);



//monngodb connection
const mongoose = require('mongoose');
mongoose.connect(process.env.MongoDB_URI).then(() => {
    console.log('Connected to MongoDB');
    app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
}).catch((error) => {
    console.error('Error connecting to MongoDB:', error);
});


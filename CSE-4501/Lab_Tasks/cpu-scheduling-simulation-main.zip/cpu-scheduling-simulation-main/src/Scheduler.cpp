#include "Scheduler.hpp"

// FCFS Implementation
void FCFSScheduler::addProcess(Process* process) {
    // Ideally check if process is state READY before adding
    process->setState(ProcessState::READY);
    readyQueue.push(process);
}

Process* FCFSScheduler::nextProcess() {
    if (readyQueue.empty()) {
        return nullptr;
    }
    
    while (!readyQueue.empty() && readyQueue.front()->getState() == ProcessState::TERMINATED) {
        readyQueue.pop();
    }
    
    if (readyQueue.empty()) {
        return nullptr;
    }

    Process* p = readyQueue.front();
    
    return p;
}


void SJFScheduler::addProcess(Process* process) {
    // TODO
}

Process* SJFScheduler::nextProcess() {
    

    // TODO

    Process* p = nullptr;
    
    return p;
}

void PreemptiveSJFScheduler::addProcess(Process* process) {
    // TODO
}

Process* PreemptiveSJFScheduler::nextProcess() {
    // TODO

    Process* p = nullptr;
    
    return p;
}

void PriorityScheduler::addProcess(Process* process) {
    // TODO
}

Process* PriorityScheduler::nextProcess() {
    // TODO

    Process* p = nullptr;
    
    return p;
}

void RRScheduler::addProcess(Process* process) {
    // TODO
}

Process* RRScheduler::nextProcess() {
    // TODO

    Process* p = nullptr;
    
    return p;
}